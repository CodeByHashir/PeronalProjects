export type SentimentCategory = 'youtube' | 'ecommerce' | 'news' | 'social' | 'blog';
export type SentimentLabel = 'positive' | 'negative' | 'neutral';

export interface SentimentResult {
  score: number;
  label: SentimentLabel;
  confidence: number;
}

export interface Comment {
  id: string;
  text: string;
  author: string;
  timestamp: string;
  sentiment: SentimentLabel;
  likes?: number;
  replies?: number;
}

export interface SentimentAnalysis {
  url: string;
  category: SentimentCategory;
  title?: string;
  sentiment: SentimentResult;
  keywords?: string[];
  summary?: string;
  timestamp: string;
  comments: Comment[];
  commentStats?: {
    total: number;
    positive: number;
    negative: number;
    neutral: number;
  };
}